/* Name: (Jaskaran Chawla)
Date: (4/2/2022) Section:
Module 10:
Section: 0006
Assignment: (Assignment#10)
Due Date: (4/3/2022)
About this project: (import and export from a file)
Assumptions: ()
 All work below was performed by (Jaskaran Chawla) */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cctype>
#include <vector>

using namespace std;
void DefineArrays(string [], string [], string [], int []);
void DeadAvengersName(string [], string [], vector<int> &deadIndex);
void DeadAvengerVectorSet(string [], vector<int> &deadIndex);
void AliveAvengerByGender(string avengerGender[], string avengerDeath[], int numAppearances[]);
const int NUM_AVENGERS =173;                        //Setting array sizes
int main()
{
    ifstream avengersData;

    vector<int> deadIndex;                           //Defining vectors
    string avengersNames[NUM_AVENGERS];              //
    string avengerGender[NUM_AVENGERS];
    string avengerDeath[NUM_AVENGERS];
    int numAppearances[NUM_AVENGERS];                //Creating string and int arrays
    DefineArrays(avengersNames, avengerGender, avengerDeath, numAppearances);        //Defining all arrays
    char userProgramOption;          //Define variables
    cout << "Welcome to the Avengers program!" <<endl;
    cout <<"A) Display count and names of the Avengers who who have died at least once ...\n"
           "B) Display average number of appearances of Avengers who have never died by gender..."
           <<endl;
    cout << "Select an option (A-B)..";
    cin >> userProgramOption;
    if(toupper(userProgramOption) == 'A')            //Allows user to enter the lowercase
    {
        DeadAvengersName(avengersNames,avengerDeath, deadIndex);
    }
    else if(toupper(userProgramOption) == 'B')      //Allows user to enter the lowercase
    {
         cout <<"Display count of Avengers who have never Died by gender..."<<endl;
         AliveAvengerByGender(avengerGender, avengerDeath, numAppearances);
    }
    else
    cout<<"Invalid option entered"<<endl;

    return 0;
}

void DefineArrays(string avengersNames[], string avengerGender[], string avengerDeath[], int numAppearances[])
{
    ifstream dataFile;
    dataFile.open("AvengersData.txt");        //Connects program to file
    if(dataFile)
    {

       string names,app,gender,death;           //gets all the colums name
       int index = 0;
       while (dataFile >>names>>app>>gender>>death)
       {
           avengersNames[index] = names;             //Define arrays
           numAppearances[index] = stoi(app);
           avengerGender[index] = gender;
           avengerDeath[index] = death;
           index++;
       }

    }
    dataFile.close();  //closes access to datafile

}
void DeadAvengersName(string avengersNames[], string avengerDeath[], vector<int> &deadIndex)
{   freopen( "OutputA.txt", "w", stdout );     //Redirects output to OutputA.txt
    ofstream outputFile;      //creates object
    //outputFile.open("OutputA.txt");
    DeadAvengerVectorSet(avengerDeath, deadIndex);
    cout<<"Display name and count of Avengers who have died at least once "<<endl;
    //outputFile <<"Display name and count of Avengers who have died at least once "<<endl;
    cout<<"The following Avengers have died at least once .... " <<endl;
    //outputFile <<"The following Avengers have died at least once .... "<<endl;

    for(int i =0; i < deadIndex.size(); i++)
    {
        cout <<avengersNames[(deadIndex.at(i))]<<endl;             //Output values in the dead index vector
        //outputFile <<avengersNames[(deadIndex.at(i))]<<endl;
    }
    double numberOfDead = deadIndex.size();
    double percent = (numberOfDead/NUM_AVENGERS* 100);
    cout<<"The number of Avengers have died at least once = " << deadIndex.size() <<endl;
    cout<<"The percentage of Avengers have died at least once " << percent <<endl;
    //outputFile <<"The number of Avengers have died at least once = " << deadIndex.size() <<endl;
    //outputFile <<"The percentage of Avengers have died at least once " << percent <<endl;

}

void DeadAvengerVectorSet(string avengerDeath[], vector<int> &deadIndex)
{
    double amountOfDead = 0;
    for(int i = 0; i < NUM_AVENGERS; i++)
    {
        if(avengerDeath[i] == "YES")
        {
            deadIndex.push_back(i);        //Push a new dead into the vector
        }
    }

}
void AliveAvengerByGender(string avengerGender[], string avengerDeath[], int numAppearances[])
{
    //ofstream outputFile;
    freopen( "OutputB.txt", "w", stdout );          //Redirects test to output B
    cout <<"Display count of Avengers who have never Died by gender..."<<endl;
    double appAverageM =0, appAverageF=0, numOfMen = 0, numOfWo= 0;
    for(int i = 0; i < NUM_AVENGERS; i++)
    {
        if(avengerDeath[i] == "NO" && avengerGender[i] == "MALE")
        {
            appAverageM += numAppearances[i];      //Ads to the average
            numOfMen++;
        }
        else if(avengerDeath[i] == "NO" && avengerGender[i] == "FEMALE")
        {
            appAverageF += numAppearances[i];      //Ads to the average
            numOfWo++;
        }


    }
    cout <<"The average number of appearances of Avengers who have never Died " <<endl;   //Writes appearances and all
    cout << "male  = " <<(appAverageM/numOfMen)<<endl;
    cout << "Female =" <<(appAverageF/numOfWo) <<endl;

}

/*
 * chawla@linprog4.cs.fsu.edu:~/Chapter10>g++ -std=c++11 main.cpp
chawla@linprog4.cs.fsu.edu:~/Chapter10>a.out
Welcome to the Avengers program!
A) Display count and names of the Avengers who who have died at least once ...
B) Display average number of appearances of Avengers who have never died by gender...
Select an option (A-B)..A
chawla@linprog4.cs.fsu.edu:~/Chapter10>a.out
Welcome to the Avengers program!
A) Display count and names of the Avengers who who have died at least once ...
B) Display average number of appearances of Avengers who have never died by gender...
Select an option (A-B)..B
Display count of Avengers who have never Died by gender...
chawla@linprog4.cs.fsu.edu:~/Chapter10>
 *
 */
